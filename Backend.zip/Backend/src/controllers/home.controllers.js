export const home = (req, res) => {

}

export const gethomes = (req, res) => {
    
}