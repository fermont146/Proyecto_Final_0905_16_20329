import User from '../models/user'


export const signUp = async (req, res) => {
        res.json('singup')
}

export const signIn = async (rec, res) => {
    res.json('sigin')
}