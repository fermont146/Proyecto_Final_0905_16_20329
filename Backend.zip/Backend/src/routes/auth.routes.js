import {Router} from 'express'

const router = Router()

import * as autControl from '../controllers/auth.controller'

router.post('/singup', autControl.signUp);
router.post('/signin', autControl.signIn);

export default router 
