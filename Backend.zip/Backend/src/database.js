/*import mongoose from 'mongoose'

   mongoose.connect('mongodb://localhost/userdb', { useNewUrlParser: true, useUnifiedTopology: true })
   .then(db => console.log('db Conectada', db.connection.host))
   .catch(err => console.error(error));
 
*/

const mongoose = require('mongoose');
const url = 'mongodb://172.17.0.2:27017/dbuser';

mongoose.connect(url, { useNewUrlParser: true, useUnifiedTopology: true })
  .then(() => {
    console.log('Conexión a MongoDB exitosa');
  })
  .catch((error) => {
    console.error('Error al conectar a MongoDB:', error);
  });