import app from './app'
import './database'

app.listen(3000);

console.log('port: ', 3000);
